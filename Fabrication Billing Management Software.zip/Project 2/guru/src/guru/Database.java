
package guru;
import java.sql.*;
import javax.swing.JOptionPane;
import net.ucanaccess.commands.*;
import net.ucanaccess.complex.*;
import net.ucanaccess.console.*;
import net.ucanaccess.converters.*;
import net.ucanaccess.ext.*;
import net.ucanaccess.jdbc.*;
import net.ucanaccess.triggers.*;
import net.ucanaccess.util.*;
import net.proteanit.sql.*;

/**
 *
 * @author MOHAN
 */
public class Database {
    public Connection conn=null;
    public Statement statement=null;
    public PreparedStatement pst=null;
    public ResultSet rs=null;
    
    public Database()
    {
       try
        {
              Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            conn=DriverManager.getConnection("jdbc:ucanaccess://F:\\gurufab.accdb");
             
        }
        catch(Exception e1) 
        {
            JOptionPane.showMessageDialog(null,e1);
        }         
    }
}
