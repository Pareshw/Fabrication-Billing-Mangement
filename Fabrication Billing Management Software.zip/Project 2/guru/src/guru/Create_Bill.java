

package guru;
import java.awt.print.PrinterException;

import java.sql.*; 
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;


public class Create_Bill extends javax.swing.JFrame {
    public Connection conn=null;
    public PreparedStatement pst=null;
    public ResultSet rs=null;
    public Statement statement=null;
     DefaultTableModel model;
     int bno,icode,qty;
 
     String itemn;
     java.sql.Date db;
     SimpleDateFormat s;
     Date date;
     float Amount;
     int[][] arr; 

 
      Object row[]=new Object [5];
    public Create_Bill() {
        
        initComponents();
        showDate();
        
        Object[] col={"Item Code","Item Name","Quantity","Rate","Amount"};
        model=new DefaultTableModel();
        model.setColumnIdentifiers(col);
        jTable1.setModel(model); 
          try{
               Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
           conn=DriverManager.getConnection("jdbc:ucanaccess://F:\\gurufab.accdb");
            statement=conn.createStatement();
            rs=statement.executeQuery(" select max(Billn) from Bills ");
           
              rs.next();
              if(rs!=null)
              {
              bno=rs.getInt(1);
              bno++;
              System.out.println(Integer.toString(bno));
              jTextField1.setText(Integer.toString(bno));
              } 
              else{
                    bno=1;
             jTextField1.setText(Integer.toString(bno));
              }
        } catch (Exception ex) {
         Logger.getLogger(AddItem.class.getName()).log(Level.SEVERE, null,ex);
         JOptionPane.showMessageDialog(null, ex);
        }
          try{
             Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
           conn=DriverManager.getConnection("jdbc:ucanaccess://F:\\gurufab.accdb");
            String prod="SELECT * FROM Material";
    
                pst = conn.prepareStatement(prod);
                rs = pst.executeQuery();
                while(rs.next()){
                    String ss = rs.getString("IName");
                    jComboBox1.addItem(ss);
                }
            }
         catch (Exception ex) {
           Logger.getLogger(AddItem.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    

    void showDate(){
        Date d= new Date();
         s = new SimpleDateFormat("dd-MMM-yyyy");
        dateta.setText(s.format(d));
        
    }

   

  
 

 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        dateta = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        area = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTextField3 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GURU FABRICATION");
        setBackground(new java.awt.Color(255, 255, 51));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Date :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 57, -1, -1));

        jLabel2.setText("Bill No. :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(626, 87, 48, 24));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(678, 89, 89, -1));

        dateta.setEditable(false);
        getContentPane().add(dateta, new org.netbeans.lib.awtextra.AbsoluteConstraints(678, 54, 89, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel3.setText("CREATE  BILL");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(277, 19, -1, -1));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\Datta\\Downloads\\icons8-save-24 (2).png")); // NOI18N
        jButton1.setText("SAVE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 560, 98, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Datta\\Downloads\\icons8-synchronize-24 (1).png")); // NOI18N
        jButton2.setText("RESET");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 560, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("SELECT ITEM :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 270, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("CUSTOMER NAME :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 184, -1, -1));

        jComboBox1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox1ItemStateChanged(evt);
            }
        });
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(166, 268, 208, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Datta\\Downloads\\icons8-add-new-26.png")); // NOI18N
        jButton3.setText("ADD");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 270, 110, -1));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\Datta\\Downloads\\icons8-cancel-26.png")); // NOI18N
        jButton4.setText("REMOVE ITEM");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 560, 170, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("ITEM CODE :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 222, -1, -1));

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 220, 92, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("QUANTITY :");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 220, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/guru/maxresdefault.jpg"))); // NOI18N
        jLabel9.setText("SSS");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-40, 0, 30, 640));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton5.setText("GENRATE RECEIPT");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 560, 200, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/guru/maxresdefault.jpg"))); // NOI18N
        jLabel11.setText("jLabel11");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 0, 610));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 200, -1));

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, 200, -1));

        area.setColumns(20);
        area.setRows(5);
        jScrollPane2.setViewportView(area);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 40, 360, 470));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("Receipt :");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 20, 100, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Item Code", "Item Name", "Quantity", "Rate", "Amount"
            }
        ));
        jTable1.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                jTable1InputMethodTextChanged(evt);
            }
        });
        jTable1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTable1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, 682, 169));

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 500, 140, 30));

        jLabel4.setText("Total :-");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 500, -1, 20));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/guru/p.png"))); // NOI18N
        jButton6.setText("PRINT");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 560, 160, 30));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
          try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            conn=DriverManager.getConnection("jdbc:ucanaccess://F:\\gurufab.accdb");
           statement=conn.createStatement();
        
        Date dc=new Date();
        
      s= new SimpleDateFormat("dd-MMM-yyyy");
            String dat = new String(s.format(dc));   
         
            
     
        
       
            
 statement.executeUpdate( "INSERT INTO Bills (BDate, Billn, Cname, Total) VALUES('"+ dat +"','"+ Integer.parseInt(jTextField1.getText())+"' , '"+jTextField2.getText()+"' , '" +Double.parseDouble(jTextField3.getText())+ "')");
        
          JOptionPane.showMessageDialog(null,"Bill Saved");
           conn.close();
            
          
            }catch(Exception e1){
              JOptionPane.showMessageDialog(null,e1);
            }
        
           jTextField4.setText("1");
  jTextField5.setText("1");
    jTextField3.setText("0.0");
    jComboBox1.setSelectedIndex(0);
    
    for( int i = model.getRowCount() - 1; i >= 0; i-- ) 
    {
        model.removeRow(i);
    } 
  
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    jTextField4.setText("0");
    jTextField2.setText(null);
    jTextField5.setText("0");
    jTextField3.setText("0.0");
    jComboBox1.setSelectedIndex(0);
    
    for( int i = model.getRowCount() - 1; i >= 0; i-- ) 
    {
        model.removeRow(i);
    }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTable1InputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_jTable1InputMethodTextChanged

        // TODO add your handling code here:
    }//GEN-LAST:event_jTable1InputMethodTextChanged

    private void jTable1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable1KeyPressed
        
    }//GEN-LAST:event_jTable1KeyPressed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
    
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
 int i=jTable1.getSelectedRow();
    if(i>=0)
    {
        model.removeRow(i);
    }
    else{
        JOptionPane.showMessageDialog(null,"Unable to Delete");
    }
    double total=0;
            
            for(int j=0;j<jTable1.getRowCount();j++){
                int amount=Integer.parseInt((String) jTable1.getValueAt(j,3));
                total+=amount;
            }
            jTextField3.setText(String.valueOf(total));        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            conn=DriverManager.getConnection("jdbc:ucanaccess://F:\\gurufab.accdb");
            icode=Integer.parseInt(jTextField4.getText());
            itemn=(String)jComboBox1.getSelectedItem();
            qty=Integer.parseInt(jTextField5.getText());
            
            
            //Object row[]=new Object [5];
            String s="Select IPrice From Material where ICode="+icode;
            rs= statement.executeQuery(s);
            rs.next();
            int price=rs.getInt(1);
            int cal=price*qty;
            //double cal=iprice*iqty;
            System.out.println(icode + " + "  + qty + " + " + itemn + " + " + price );
            row[0]=Integer.toString(icode);
            row[1]=itemn;
            row[2]=Integer.toString(qty);
            row[3]=price;
            row[4]=Integer.toString(cal);
            model.addRow(row);
            
           
            //jTable1.;
            double total=0;
            
            for(int j=0;j<jTable1.getRowCount();j++){
                int amount=Integer.parseInt((String) jTable1.getValueAt(j,4));
                total+=amount;
            }
            jTextField3.setText(String.valueOf(total));
            
            }
           catch(Exception exc){
               JOptionPane.showMessageDialog(null, exc);
            }
      
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
         double price = 0;
         double cal =0;
          double total=0;
        try{
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            conn=DriverManager.getConnection("jdbc:ucanaccess://F:\\gurufab.accdb");
            icode=Integer.parseInt(jTextField4.getText());
            itemn=(String)jComboBox1.getSelectedItem();
            qty=Integer.parseInt(jTextField5.getText());
            
            
            //Object row[]=new Object [5];
            String s="Select IPrice From Material where ICode="+icode;
            rs= statement.executeQuery(s);
            rs.next();
             price=rs.getInt(1);
            cal=price*qty;
    
            
           
            //jTable1.;
           
            
            for(int j=0;j<jTable1.getRowCount();j++){
                int amount=Integer.parseInt((String) jTable1.getValueAt(j,4));
                total+=amount;
            }
            jTextField3.setText(String.valueOf(total));
            
            }
           catch(Exception exc){
               JOptionPane.showMessageDialog(null, exc);
            } 
        
        
        area.setText("*************************************************************\n");
        area.setText(area.getText()+"*                          GURU Fabrication Store                       *\n");
        area.setText(area.getText()+"*************************************************************\n");
        
       Date obj = new Date();
       
       String date = obj.toString();
       //float rat
         area.setText(area.getText()+"\n"+date+"\n\n");
         area.setText(area.getText()+"Customer Name :        "+jTextField2.getText()+"\n\n");
       
         area.setText(area.getText()+"Bill No.                            "+jTextField1.getText()+"\n\n");
         area.setText(area.getText()+"Item Name          Quantity          Rate          Total Amt.          \n\n");

        for(int i= 0; i<jTable1.getRowCount() ; i++)
        {
     
                area.setText(area.getText()+jTable1.getValueAt(i,1)+"                    "+jTable1.getValueAt(i, 2)+"                    "+jTable1.getValueAt(i, 3)+"                    "+jTable1.getValueAt(i, 4)+                    "\n");
        
 
        }
       area.setText(area.getText()+"\n\n"); 
        area.setText(area.getText()+"Grand Total:                  "+total+"\n\n");
       area.setText(area.getText()+"\n\n\n\n                                             Signature\n\n");
          area.setText(area.getText()+"*************************************************************\n");
           area.setText(area.getText()+"*                    Thank u..., Visit Again                            *\n");
            area.setText(area.getText()+"*************************************************************");
            
            
      
 
  
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jComboBox1ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox1ItemStateChanged
     
      
    }//GEN-LAST:event_jComboBox1ItemStateChanged

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
     
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        try {
            area.print();        // TODO add your handling code here:
        } catch (PrinterException ex) {
 JOptionPane.showMessageDialog(null,ex);        }
    }//GEN-LAST:event_jButton6ActionPerformed

   
 /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Create_Bill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Create_Bill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Create_Bill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Create_Bill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
 
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Create_Bill().setVisible(true);
            }
        });
    }
               
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea area;
    private javax.swing.JTextField dateta;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    public javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    public javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables

    
}
